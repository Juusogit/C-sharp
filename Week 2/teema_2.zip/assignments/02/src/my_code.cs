using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


/*
Kysy käyttäjältä kuukauden numero.
Tulosta sen jälkeen onko nyt "syksy", "talvi", "kevät" vai "kesä".
Käytä switch-case rakennetta. Jos käyttäjä syötti kuukauden numeron väärin, niin tulosta
"et antanut kuukauden numeroa oikein"
*/

namespace Projekti
{
    class Program
    {
        static void Main()
        {
            //Your code here
        }
    }
}

